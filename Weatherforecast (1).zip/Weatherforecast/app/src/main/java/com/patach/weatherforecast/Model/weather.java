package com.patach.weatherforecast.Model;

public class weather {
    String title,link,date;

    public weather(String title, String link, String date) {
        this.title = title;
        this.link = link;
        this.date = date;
    }

    public String getTitle() {
        return title;
    }

    public String getLink() {
        return link;
    }

    public String getDate() {
        return date;
    }
}
