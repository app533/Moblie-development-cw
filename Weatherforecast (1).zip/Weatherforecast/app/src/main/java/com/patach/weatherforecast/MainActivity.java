package com.patach.weatherforecast;

import static com.patach.weatherforecast.Utils.Constant.getBangladeshList;
import static com.patach.weatherforecast.Utils.Constant.getCurrentTime;
import static com.patach.weatherforecast.Utils.Constant.getGlasgowList;
import static com.patach.weatherforecast.Utils.Constant.getLandonList;
import static com.patach.weatherforecast.Utils.Constant.getMauritiusList;
import static com.patach.weatherforecast.Utils.Constant.getNewYorkList;
import static com.patach.weatherforecast.Utils.Constant.getOmanList;
import static com.patach.weatherforecast.Utils.Constant.getTimeFrame;
import static com.patach.weatherforecast.Utils.Constant.setBangladeshList;
import static com.patach.weatherforecast.Utils.Constant.setGlasgowList;
import static com.patach.weatherforecast.Utils.Constant.setLandonList;
import static com.patach.weatherforecast.Utils.Constant.setMauritiusList;
import static com.patach.weatherforecast.Utils.Constant.setNewYorkList;
import static com.patach.weatherforecast.Utils.Constant.setOmanList;
import static com.patach.weatherforecast.Utils.Constant.setTimeFrame;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.patach.weatherforecast.Model.weather;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity implements
        View.OnClickListener {
    ArrayAdapter arrayAdapter;
    private RecyclerView recyclerView;
    TextView rawDataDisplay;
    ArrayList<String> pubDateList =new ArrayList<String>();
    ArrayList<String> stringTitleList =new ArrayList<String>();
    ArrayList<String> stringLinkList =new ArrayList<String>();

    ArrayList<weather> weatherArrayList =new ArrayList<weather>();
    ProgressDialog progressDialog;
   // private TextView rawDataDisplay;
    private Button startButton;
    private String url1="https://weather-broker-cdn.api.bbci.co.uk/en/forecast/rss/3day/2648579";
    boolean GlasgowClicked =true,LondonClicked=false,OmanClicked=false,BangladeshClicked=false,NewYorkClicked=false,MauritiusClicked=false;

    public String[] mColors = {
            "5BA477E8", "66E6EF8F", "66FFA6AD", "5693E6A6", "52FF87B4", "57B0E3FF", "5772E1DD",
            "5BA477E8", "66E6EF8F", "66FFA6AD", "5693E6A6", "52FF87B4", "57B0E3FF", "5772E1DD",
            "5BA477E8", "66E6EF8F", "66FFA6AD", "5693E6A6", "52FF87B4", "57B0E3FF", "5772E1DD",
            "5BA477E8", "66E6EF8F", "66FFA6AD", "5693E6A6", "52FF87B4", "57B0E3FF", "5772E1DD",
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView=findViewById(R.id.recyclerView);
        rawDataDisplay=findViewById(R.id.rawDataDisplay);
        startButton=findViewById(R.id.startButton);
        startButton.setOnClickListener(this);
         progressDialog =new ProgressDialog(MainActivity.this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
         // update the record after the selected time frame

        if(getCurrentTime().contains(getTimeFrame(this))){
            clearAllRecord();
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id){
            case R.id.glasgow:
                url1="https://weather-broker-cdn.api.bbci.co.uk/en/forecast/rss/3day/2648579";
                GlasgowClicked =true;LondonClicked=false;OmanClicked=false;
                BangladeshClicked=false;NewYorkClicked=false;MauritiusClicked=false;
                return true;
            case R.id.london:
                url1="https://weather-broker-cdn.api.bbci.co.uk/en/forecast/rss/3day/2643743";
                GlasgowClicked =false;LondonClicked=true;OmanClicked=false;
                BangladeshClicked=false;NewYorkClicked=false;MauritiusClicked=false;
                return true;
            case R.id.newYork:
                url1="https://weather-broker-cdn.api.bbci.co.uk/en/forecast/rss/3day/5128581";
                GlasgowClicked =false;LondonClicked=false;OmanClicked=false;
                BangladeshClicked=false;NewYorkClicked=true;MauritiusClicked=false;
                return true;
            case R.id.mauritius:
                url1="https://weather-broker-cdn.api.bbci.co.uk/en/forecast/rss/3day/287286";
                GlasgowClicked =false;LondonClicked=false;OmanClicked=false;
                BangladeshClicked=false;NewYorkClicked=false;MauritiusClicked=true;
                return true;
            case R.id.oman:
                url1="https://weather-broker-cdn.api.bbci.co.uk/en/forecast/rss/3day/934154";
                GlasgowClicked =false;LondonClicked=false;OmanClicked=true;
                BangladeshClicked=false;NewYorkClicked=false;MauritiusClicked=false;
                return true;
            case R.id.bangladesh:
                url1="https://weather-broker-cdn.api.bbci.co.uk/en/forecast/rss/3day/1185241";
                GlasgowClicked =false;LondonClicked=false;OmanClicked=false;
                BangladeshClicked=true;NewYorkClicked=false;MauritiusClicked=false;
                return true;
            case R.id.time1:
                setTimeFrame(this,"8:00 to 20:00");
                return true;
            case R.id.time2:
                setTimeFrame(this,"12:00 to 24:00");
                return true;
            case R.id.time3:
                setTimeFrame(this,"6:00 to 22:00");
                return true;
            case R.id.time4:
                setTimeFrame(this,"22:00 to 6:00");
                return true;


            default:
                return super.onOptionsItemSelected(item);
        }
    }




    @Override
    public void onClick(View v)
    {
        Log.e("MyTag","in onClick");
        if(GlasgowClicked){
            if(getGlasgowList(this)==null){
                startProgress();
                stringTitleList.clear();
                stringLinkList.clear();
                pubDateList.clear();
            }
            else {
                weatherArrayList=getGlasgowList(MainActivity.this);
                displayList();
            }
        }
        if(LondonClicked){
            if(getLandonList(this)==null){
                startProgress();
                stringTitleList.clear();
                stringLinkList.clear();
                pubDateList.clear();
            }
            else {
                weatherArrayList=getLandonList(MainActivity.this);
                displayList();
            }
        }
        if(NewYorkClicked){
            if(getNewYorkList(this)==null){
                startProgress();
                stringTitleList.clear();
                stringLinkList.clear();
                pubDateList.clear();
            }
            else {
                weatherArrayList=getNewYorkList(MainActivity.this);
                displayList();
            }
        }
        if(OmanClicked){
            if(getOmanList(this)==null){
                startProgress();
                stringTitleList.clear();
                stringLinkList.clear();
                pubDateList.clear();
            }
            else {
                weatherArrayList=getOmanList(MainActivity.this);
                displayList();
            }
        }
        if(BangladeshClicked){
            if(getBangladeshList(this)==null){
                startProgress();
                stringTitleList.clear();
                stringLinkList.clear();
                pubDateList.clear();
            }
            else {
                weatherArrayList=getBangladeshList(MainActivity.this);
                displayList();
            }
        }
        if(MauritiusClicked){
            if(getMauritiusList(this)==null){
                startProgress();
                stringTitleList.clear();
                stringLinkList.clear();
                pubDateList.clear();
            }
            else {
                weatherArrayList=getMauritiusList(MainActivity.this);
                displayList();
            }
        }




        Log.e("MyTag","after startProgress");
    }



    public void startProgress(){

//new processInBackground().execute();

        new Thread(new Task(url1)).start();
}

    private class Task implements Runnable
    {
        private String url;
        public Task(String aurl)
        {
            url = aurl;
        }
        @Override
        public void run()
        {
            URL aurl;
            URLConnection yc;
            BufferedReader in = null;
            String inputLine = "";
            Log.e("MyTag","in run");
            try
            {
                Log.e("MyTag","in try");
                aurl = new URL(url);
                yc = aurl.openConnection();
                in = new BufferedReader(new
                        InputStreamReader(yc.getInputStream()));
                Log.e("MyTag","after ready");

                while ((inputLine = in.readLine()) != null)
                {
                  //  result = result + inputLine;
                    Log.e("MyTag",inputLine);
                }
                in.close();
            }
            catch (IOException ae)
            {
                Log.e("MyTag", "ioexception in run");
            }
            //
            // Now that you have the xml data you can parse it
            //
            // Now update the TextView to display raw XML data
            // Probably not the best way to update TextView
            // but we are just getting started !


            MainActivity.this.runOnUiThread(new Runnable()
            {
                public void run() {
                    Log.d("UI thread", "I am the UI thread");
                    new processInBackground().execute();
                }
            });
        }
    }







public InputStream getInputStream(URL url){

        try {
             return url.openConnection().getInputStream();
        }
        catch (IOException e){
            return null;
        }
}



    public class processInBackground extends AsyncTask<Integer ,Void ,Exception>{
        Exception exception =null;

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        progressDialog.setMessage("Loading ...");
        progressDialog.show();
    }

    @Override
    protected Exception doInBackground(Integer... integers) {

        try
        {
            URL url=new URL(url1);
            XmlPullParserFactory xmlPullParserFactory=XmlPullParserFactory.newInstance();
            xmlPullParserFactory.setNamespaceAware(false);
            XmlPullParser xmlPullParser=xmlPullParserFactory.newPullParser();
            xmlPullParser.setInput(getInputStream(url),"UTF_8");
            boolean insideItem =false;
            int eventType =xmlPullParser.getEventType();
            while (eventType!=XmlPullParser.END_DOCUMENT){
                if(eventType ==XmlPullParser.START_TAG){
                    if(xmlPullParser.getName().equalsIgnoreCase("item")){
                        insideItem =true;
                    }
                    else if(xmlPullParser.getName().equalsIgnoreCase("title")){
                        if(insideItem){
                            stringTitleList.add(xmlPullParser.nextText());
                        }
                    }
                    else if(xmlPullParser.getName().equalsIgnoreCase("link")){
                        if(insideItem){
                            stringLinkList.add(xmlPullParser.nextText());
                        }
                    }
                    else if(xmlPullParser.getName().equalsIgnoreCase("pubDate")){
                        if(insideItem){
                            pubDateList.add(xmlPullParser.nextText());
                        }
                    }
                }
                else if(eventType ==XmlPullParser.END_TAG && xmlPullParser.getName().equalsIgnoreCase("item")){
                    insideItem =false;
                }
                eventType =xmlPullParser.next();
            }

        }
        catch (MalformedURLException e){
            exception=e;
        }
        catch (XmlPullParserException e){
            exception=e;
        }
        catch (IOException e){
            exception=e;
        }
        return exception;
    }

    @Override
    protected void onPostExecute(Exception s) {
        super.onPostExecute(s);
       saveData();
    }
}
    public class ArrayAdapter extends RecyclerView.Adapter<ArrayAdapter.ImageViewHoler> {

        public ArrayAdapter(){
        }
        @NonNull
        @Override
        public ArrayAdapter.ImageViewHoler onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v= LayoutInflater.from(MainActivity.this).inflate(R.layout.item_rss,parent,false);
            return  new ImageViewHoler(v);
        }

        @Override
        public void onBindViewHolder(@NonNull final ArrayAdapter.ImageViewHoler holder, int position) {
            holder.place_name.setText(weatherArrayList.get(position).getTitle());
            holder.place_link.setText(weatherArrayList.get(position).getLink());
            holder.date.setText(weatherArrayList.get(position).getDate());
           holder.cardView.setBackgroundColor(Color.parseColor ("#"+mColors[new Random().nextInt(28)]));
            if(weatherArrayList.get(position).getTitle().toLowerCase().contains("clear sky".toLowerCase())){
                holder.imageview.setImageDrawable(getDrawable(R.drawable.day_clear));
            }
            if(weatherArrayList.get(position).getTitle().toLowerCase().contains("sunny".toLowerCase())){
                holder.imageview.setImageDrawable(getDrawable(R.drawable.day_sunny));
            }
            if(weatherArrayList.get(position).getTitle().toLowerCase().contains("light rain".toLowerCase())){
                holder.imageview.setImageDrawable(getDrawable(R.drawable.rain));
            }
            if(weatherArrayList.get(position).getTitle().toLowerCase().contains("light cloud".toLowerCase())){
                holder.imageview.setImageDrawable(getDrawable(R.drawable.cloudy));
            }
            if(weatherArrayList.get(position).getTitle().toLowerCase().contains("thunder showers".toLowerCase())){
                holder.imageview.setImageDrawable(getDrawable(R.drawable.day_rain_thunder));
            }
            if(weatherArrayList.get(position).getTitle().toLowerCase().contains("thunder".toLowerCase())){
                holder.imageview.setImageDrawable(getDrawable(R.drawable.thunder));
            }
            if(weatherArrayList.get(position).getTitle().toLowerCase().contains("thundery showers".toLowerCase())){
                holder.imageview.setImageDrawable(getDrawable(R.drawable.rain_thunder));
            }
            if(weatherArrayList.get(position).getTitle().toLowerCase().contains("drizzle".toLowerCase())){
                holder.imageview.setImageDrawable(getDrawable(R.drawable.sleet));
            }
            if(weatherArrayList.get(position).getTitle().toLowerCase().contains("Partly cloud".toLowerCase())){
                holder.imageview.setImageDrawable(getDrawable(R.drawable.cloudy));
            }


        }

        @Override
        public int getItemCount() {
            return weatherArrayList.size();
        }

        public class ImageViewHoler extends RecyclerView.ViewHolder {
            TextView place_name,place_link,date;
            ImageView imageview;
            CardView cardView;
            public ImageViewHoler(@NonNull View itemView) {
                super(itemView);
                place_name=itemView.findViewById(R.id.place_name);
                place_link=itemView.findViewById(R.id.place_link);
                date=itemView.findViewById(R.id.date);
                imageview=itemView.findViewById(R.id.imageview);
                cardView=itemView.findViewById(R.id.cardView);
            }
        }
    }

    public void saveData(){
        weatherArrayList.clear();
        for(int position=0;position<3;position++){
            weatherArrayList.add(new weather(stringTitleList.get(position),stringLinkList.get(position),pubDateList.get(position)));
        }
        arrayAdapter=new ArrayAdapter();
        rawDataDisplay.setVisibility(View.GONE);
        recyclerView.setAdapter(arrayAdapter);
        recyclerView.setVisibility(View.VISIBLE);
        if(GlasgowClicked){
            setGlasgowList(this,weatherArrayList);
        }
        if(LondonClicked){
            setLandonList(this,weatherArrayList);
        }
        if(NewYorkClicked){
          setNewYorkList(this,weatherArrayList);
        }
        if(OmanClicked){
        setOmanList(this,weatherArrayList);
        }
        if(BangladeshClicked){
           setBangladeshList(this,weatherArrayList);
        }
        if(MauritiusClicked){
         setMauritiusList(this,weatherArrayList);
        }

        progressDialog.dismiss();
    }
    public void displayList(){
        arrayAdapter=new ArrayAdapter();
        rawDataDisplay.setVisibility(View.GONE);
        recyclerView.setAdapter(arrayAdapter);
        recyclerView.setVisibility(View.VISIBLE);
    }


    public void clearAllRecord(){
        setBangladeshList(this,null);
        setGlasgowList(this,null);
        setNewYorkList(this,null);
        setLandonList(this,null);
        setMauritiusList(this,null);
        setGlasgowList(this,null);
    }

}