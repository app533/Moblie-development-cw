package com.patach.weatherforecast.Utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.patach.weatherforecast.Model.weather;

import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Constant {

    public static void setGlasgowList(Context context, ArrayList<weather> weatherArrayList) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        Gson gson = new Gson();
        String json = gson.toJson(weatherArrayList);
        prefs.edit().putString("glasgowdata", json).commit();
    }

    public static ArrayList<weather> getGlasgowList(Context context) {
        ArrayList<weather> weatherArrayList =null;
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        Gson gson = new Gson();
        String json = prefs.getString("glasgowdata", null);
        Type type = new TypeToken<ArrayList<weather>>() {
        }.getType();
        weatherArrayList= gson.fromJson(json, type);
        return weatherArrayList;
    }


    public static void setLandonList(Context context, ArrayList<weather> weatherArrayList) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        Gson gson = new Gson();
        String json = gson.toJson(weatherArrayList);
        prefs.edit().putString("landondata", json).commit();
    }

    public static ArrayList<weather> getLandonList(Context context) {
        ArrayList<weather> weatherArrayList =null;
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        Gson gson = new Gson();
        String json = prefs.getString("landondata", null);
        Type type = new TypeToken<ArrayList<weather>>() {
        }.getType();
        weatherArrayList= gson.fromJson(json, type);
        return weatherArrayList;
    }

    public static void setNewYorkList(Context context, ArrayList<weather> weatherArrayList) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        Gson gson = new Gson();
        String json = gson.toJson(weatherArrayList);
        prefs.edit().putString("newyorkdata", json).commit();
    }

    public static ArrayList<weather> getNewYorkList(Context context) {
        ArrayList<weather> weatherArrayList =null;
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        Gson gson = new Gson();
        String json = prefs.getString("newyorkdata", null);
        Type type = new TypeToken<ArrayList<weather>>() {
        }.getType();
        weatherArrayList= gson.fromJson(json, type);
        return weatherArrayList;
    }

    public static void setOmanList(Context context, ArrayList<weather> weatherArrayList) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        Gson gson = new Gson();
        String json = gson.toJson(weatherArrayList);
        prefs.edit().putString("omandata", json).commit();
    }

    public static ArrayList<weather> getOmanList(Context context) {
        ArrayList<weather> weatherArrayList =null;
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        Gson gson = new Gson();
        String json = prefs.getString("omandata", null);
        Type type = new TypeToken<ArrayList<weather>>() {
        }.getType();
        weatherArrayList= gson.fromJson(json, type);
        return weatherArrayList;
    }

    public static void setMauritiusList(Context context, ArrayList<weather> weatherArrayList) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        Gson gson = new Gson();
        String json = gson.toJson(weatherArrayList);
        prefs.edit().putString("mauritiusdata", json).commit();
    }

    public static ArrayList<weather> getMauritiusList(Context context) {
        ArrayList<weather> weatherArrayList =null;
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        Gson gson = new Gson();
        String json = prefs.getString("mauritiusdata", null);
        Type type = new TypeToken<ArrayList<weather>>() {
        }.getType();
        weatherArrayList= gson.fromJson(json, type);
        return weatherArrayList;
    }

    public static void setBangladeshList(Context context, ArrayList<weather> weatherArrayList) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        Gson gson = new Gson();
        String json = gson.toJson(weatherArrayList);
        prefs.edit().putString("bangladeshdata", json).commit();
    }

    public static ArrayList<weather> getBangladeshList(Context context) {
        ArrayList<weather> weatherArrayList =null;
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        Gson gson = new Gson();
        String json = prefs.getString("bangladeshdata", null);
        Type type = new TypeToken<ArrayList<weather>>() {
        }.getType();
        weatherArrayList= gson.fromJson(json, type);
        return weatherArrayList;
    }

    public static String getCurrentTime(){
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
        return   sdf.format(new Date());
    }

    public static void setTimeFrame(Context context , String s){
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        prefs.edit().putString("timeFrame", s).commit();
    }
    public static String getTimeFrame(Context context){
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        return prefs.getString("timeFrame","8:00 to 20:00");
    }


}
